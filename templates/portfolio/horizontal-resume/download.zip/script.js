$(document).ready(function(){
  $(".owl-carousel").owlCarousel({
    margin: 30,
    autoWidth: false,
    items: 3
  });
});