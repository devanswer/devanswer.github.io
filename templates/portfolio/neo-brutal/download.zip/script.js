var typed = new Typed("#typed", {
  strings: ["Welcome to my personal Website"],
  typeSpeed: 110,
  startDelay: 500,
  loop: true,
  loopCount: Infinity,
  backDelay: 1000
});